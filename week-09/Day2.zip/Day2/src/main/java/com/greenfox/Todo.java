package com.greenfox;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Controller;

@AllArgsConstructor
@Getter
@Setter
@Controller
public class Todo {

    int id;
    String title;
    boolean urgent;
    boolean done;

    public Todo(int id, String title) {
        this(id, title, false, false);
    }


}
